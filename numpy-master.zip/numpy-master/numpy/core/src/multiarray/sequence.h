#ifndef _NPY_ARRAY_SEQUENCE_H_
#define _NPY_ARRAY_SEQUENCE_H_

extern NPY_NO_EXPORT PySequenceMethods array_as_sequence;

#endif
