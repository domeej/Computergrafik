********
Glossary
********

.. toctree::

.. automodule:: numpy.doc.glossary
